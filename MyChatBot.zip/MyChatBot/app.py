from flask import Flask, render_template, request
import aiml

app = Flask(__name__)
kernel = aiml.Kernel()
kernel.learn("naumansbot.aiml")

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/get")
def get_bot_response():
    userText = request.args.get('msg')
    return kernel.respond(userText)


if __name__ == "__main__":
    app.run()
